import './normal.css';
import './App.css';

import msgIcon from './assets/message.svg';
import home from './assets/home.svg';
import saved from './assets/bookmark.svg';
import rocket from './assets/rocket.svg';
import hacker from './assets/hacker-image.jpg';
import user from './assets/user-icon1.jpeg';
function App() {
  return (
    <div className="App">
       
      <aside className="Sidemenu">
        <div className="side-menu-button">
          <span>+</span>
          New Chat
         </div>
         
       <div className="container">
       <div className='upperSideBottom'>
          <button className='query'>
            <img src={msgIcon} alt=''/>What is programming..?
          </button>
          <button className='query'>
            <img src={msgIcon} alt=''/>How to use..?
          </button>
        </div>
        <div className='lowerSide'>
          <div className="space"></div>
          <div className='listItems'><img src={home} alt='' className='listItemsImg'/>Home</div>
          <div className='listItems'><img src={saved} alt='' className='listItemsImg'/>Saved</div>
          <div className='listItems'><img src={rocket} alt='' className='listItemsImg'/>Update</div>
          <div className='main'></div>
        </div>
      
       </div>
         
         <div class="logout-container">
    <button class="logout-button">Register</button>
</div>

      </aside>
      <section class="chatbox">
    <div class="header">
   
        <div class="navbar">
            <ul>
                <li><a href="#login">About</a></li>
                <li><a href="#blog">Blog</a></li>
                <li><a href="#features">Features</a></li>
                <li><a href="#about">LogOut</a></li>
            </ul>
            <div>
  <img src={user} alt='hacker' className='user'/>
</div>
        </div>
        <h1> SANGPT </h1>
    </div>
<div>
  <img src={hacker} alt='hacker' className='image'/>
</div>
    <div class="content">
        <div class="chat-log">
            <div class="chat-message">
                <div class="avatar"></div>
                <div class="message"></div>
            </div>
        </div>
        <div class="chat-input-holder">
           <div class="input-container">
               <textarea class="chat-input-textarea" placeholder="Type your message here...."></textarea>
            <div id="submit">⮞</div>
       </div>
</div>

    </div>
</section>


     
    </div>
  );
}

export default App;
